from __future__ import annotations

from collections import Counter
from pathlib import Path

import matplotlib.pyplot as plt
import numpy as np
import pandas as pd
from pymatgen.core import Composition


DATA_ROOT = Path("/Volumes/J/research/2D_materials/3.23/paper_conclusions")
BASE = DATA_ROOT / "figure_assets"
PREP = DATA_ROOT / "exfoliation_energy_preparation_table.csv"
MP = Path("/Volumes/J/research/2D_materials/3.13_new_exfo_test/mp_data_14000.csv")
OUT_CSV = BASE / "data" / "composition_overview_data.csv"
OUT_PNG = BASE / "figures" / "figure_composition_overview.png"
OUT_PDF = BASE / "figures" / "figure_composition_overview.pdf"


plt.rcParams.update(
    {
        "font.family": "serif",
        "font.serif": ["Times New Roman", "STIXGeneral", "DejaVu Serif"],
        "mathtext.fontset": "stix",
        "axes.titlesize": 15,
        "font.size": 12,
    }
)


def stoich_pattern(formula: str) -> str:
    comp = Composition(formula).fractional_composition
    amounts = sorted(comp.get_el_amt_dict().values())
    min_amount = min(amounts)
    letters = "ABCDEFGHIJKLMNOPQRSTUVWXYZ"
    parts: list[str] = []
    for idx, amount in enumerate(amounts):
        ratio = amount / min_amount
        nearest = round(ratio)
        value = int(nearest) if abs(ratio - nearest) < 1e-6 else round(ratio, 2)
        part = letters[idx] if value == 1 else f"{letters[idx]}{value}"
        parts.append(part)
    return "".join(parts)


def complexity_bucket(n_elements: int) -> str:
    if n_elements == 1:
        return "unary"
    if n_elements == 2:
        return "binary"
    if n_elements == 3:
        return "ternary"
    if n_elements == 4:
        return "quaternary"
    if n_elements == 5:
        return "quinary"
    return "other"


def percentage(counter: Counter[str]) -> dict[str, float]:
    total = sum(counter.values())
    return {k: 100.0 * v / total for k, v in counter.items()}


def write_data(
    complexity_2d: Counter[str],
    complexity_mp: Counter[str],
) -> None:
    rows: list[dict[str, object]] = []

    total_2d = sum(complexity_2d.values())
    for label, count in complexity_2d.items():
        rows.append(
            {
                "panel": "a",
                "category": label,
                "count": count,
                "percentage": 100.0 * count / total_2d,
            }
        )

    total_mp = sum(complexity_mp.values())
    for label, count in complexity_mp.items():
        rows.append(
            {
                "panel": "b",
                "category": label,
                "count": count,
                "percentage": 100.0 * count / total_mp,
            }
        )

    OUT_CSV.parent.mkdir(parents=True, exist_ok=True)
    pd.DataFrame(rows).to_csv(OUT_CSV, index=False)


def annotate_pie(ax, wedges, labels, values, outside_threshold=3.0):
    total = sum(values)
    for wedge, label, val in zip(wedges, labels, values):
        pct = 100.0 * val / total
        ang = (wedge.theta2 + wedge.theta1) / 2.0
        ang_rad = np.deg2rad(ang)
        x = np.cos(ang_rad)
        y = np.sin(ang_rad)
        if pct < outside_threshold:
            radial = 1.10 if abs(y) > 0.7 else 1.2
            if abs(y) > 0.8:
                x_shift = 0.22 if x > 0 else -0.22
                y_shift = 0.08
            else:
                x_shift = 0.08 if x > 0 else -0.08
                y_shift = 0.06
            x_text = radial * x + x_shift
            y_text = radial * y + y_shift
            ax.annotate(
                f"{label} ({pct:.1f}%)",
                xy=(0.95 * x, 0.95 * y),
                xytext=(x_text, y_text),
                ha="center",
                va="center",
                arrowprops={"arrowstyle": "-", "lw": 0.8, "color": "black"},
            )
        else:
            ax.text(
                0.67 * x,
                0.67 * y,
                f"{pct:.1f}%",
                ha="center",
                va="center",
                fontsize=12,
                weight="bold",
                color="white" if pct > 8 else "black",
            )
            ax.text(
                1.07 * x,
                1.07 * y,
                label,
                ha="center",
                va="center",
                fontsize=12,
            )


def main() -> None:
    prep_df = pd.read_csv(PREP, usecols=["formula_2d"])
    formulas_2d = prep_df["formula_2d"].dropna().tolist()

    panel_b = Counter(
        complexity_bucket(len(Composition(f).elements))
        for f in formulas_2d
    )

    mp_df = pd.read_csv(MP, usecols=["formula"])
    panel_c = Counter(
        complexity_bucket(len(Composition(f).elements))
        for f in mp_df["formula"].dropna()
    )

    write_data(panel_b, panel_c)

    complexity_order = ["unary", "binary", "ternary", "quaternary", "quinary", "other"]
    # 统一采用由蓝到红的阶梯光谱色，不再和 Method 颜色混淆
    complexity_colors = {
        "unary": "#3288bd",
        "binary": "#99d594",
        "ternary": "#e6f598",
        "quaternary": "#fee08b",
        "quinary": "#fc8d59",
        "other": "#d53e4f",
    }

    panel_b_labels = [label for label in complexity_order if label in panel_b]
    panel_b_values = [panel_b[label] for label in panel_b_labels]
    panel_b_colors = [complexity_colors[label] for label in panel_b_labels]

    panel_c_labels = [label for label in complexity_order if label in panel_c]
    panel_c_values = [panel_c[label] for label in panel_c_labels]
    panel_c_colors = [complexity_colors[label] for label in panel_c_labels]

    fig, axes = plt.subplots(1, 2, figsize=(10.8, 5.2), constrained_layout=True)

    all_data = [
        (panel_b_labels, panel_b_values, panel_b_colors),
        (panel_c_labels, panel_c_values, panel_c_colors),
    ]

    for idx, (ax, (labels, values, colors)) in enumerate(zip(axes, all_data)):
        wedges, _ = ax.pie(
            values,
            colors=colors,
            startangle=90,
            counterclock=False,
            wedgeprops={"linewidth": 0.8, "edgecolor": "white"},
        )
        annotate_pie(ax, wedges, labels, values, outside_threshold=3.0)
        ax.text(-1.22, 1.18, f"({chr(97 + idx)})", fontsize=16, fontweight="bold")
        ax.set_aspect("equal")

    fig.savefig(OUT_PNG, dpi=400, bbox_inches="tight")
    fig.savefig(OUT_PDF, bbox_inches="tight")
    print(f"Saved {OUT_PNG}")
    print(f"Saved {OUT_PDF}")
    print(f"Saved {OUT_CSV}")


if __name__ == "__main__":
    main()
