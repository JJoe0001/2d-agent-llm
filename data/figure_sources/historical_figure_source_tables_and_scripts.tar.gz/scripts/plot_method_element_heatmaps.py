from __future__ import annotations

from collections import Counter
from pathlib import Path

import matplotlib as mpl
import matplotlib.pyplot as plt
from matplotlib.patches import FancyBboxPatch
import pandas as pd
from pymatgen.core import Composition, Element

DATA_ROOT = Path("/Volumes/J/research/2D_materials/3.23/paper_conclusions")
BASE = DATA_ROOT / "figure_assets"
FIG_DIR = BASE / "figures"
DATA_DIR = BASE / "data"
INPUT = DATA_ROOT / "exfoliation_energy_preparation_table.csv"
OUT_FILES = {
    "Computational exfoliation (Mounet et al.)": (
        FIG_DIR / "figure_method_element_heatmap_mounet.png",
        FIG_DIR / "figure_method_element_heatmap_mounet.pdf",
    ),
    "Top-down approach (Zhou et al.)": (
        FIG_DIR / "figure_method_element_heatmap_zhou.png",
        FIG_DIR / "figure_method_element_heatmap_zhou.pdf",
    ),
    "GALOCS + XCP/BONDDEL hybrid (this work)": (
        FIG_DIR / "figure_method_element_heatmap_hybrid.png",
        FIG_DIR / "figure_method_element_heatmap_hybrid.pdf",
    ),
}
OUT_COMBINED_PNG = FIG_DIR / "figure_method_element_heatmaps_combined.png"
OUT_COMBINED_PDF = FIG_DIR / "figure_method_element_heatmaps_combined.pdf"
OUT_CSV = DATA_DIR / "method_element_heatmaps_data.csv"

plt.rcParams.update(
    {
        "font.family": "serif",
        "font.serif": ["Times New Roman", "STIXGeneral", "DejaVu Serif"],
        "mathtext.fontset": "stix",
        "font.size": 11,
        "axes.linewidth": 1.2,
    }
)

LAN = ["La", "Ce", "Pr", "Nd", "Pm", "Sm", "Eu", "Gd", "Tb", "Dy", "Ho", "Er", "Tm", "Yb", "Lu"]
ACT = ["Ac", "Th", "Pa", "U", "Np", "Pu", "Am", "Cm", "Bk", "Cf", "Es", "Fm", "Md", "No", "Lr"]
METHOD_ORDER = [
    "Computational exfoliation (Mounet et al.)",
    "Top-down approach (Zhou et al.)",
    "GALOCS + XCP/BONDDEL hybrid (this work)",
]


def build_positions() -> dict[str, tuple[int, int]]:
    positions: dict[str, tuple[int, int]] = {}
    for z in range(1, 119):
        el = Element.from_Z(z)
        symbol = el.symbol
        if symbol in LAN:
            positions[symbol] = (LAN.index(symbol) + 3, 9)
        elif symbol in ACT:
            positions[symbol] = (ACT.index(symbol) + 3, 10)
        else:
            positions[symbol] = (el.group, el.row)
    return positions


def text_color(rgba) -> str:
    r, g, b, _ = rgba
    # 根据亮度调整文字颜色，冷色调对高对比度要求更高
    luminance = 0.299 * r + 0.587 * g + 0.114 * b
    return "white" if luminance < 0.65 else "#1a252c"


def prepare_data() -> tuple[pd.DataFrame, pd.DataFrame]:
    df = pd.read_csv(INPUT, usecols=["source", "formula_2d"])
    global_counter: Counter[str] = Counter()
    rows: list[dict[str, object]] = []

    total_all = len(df)
    for formula in df["formula_2d"].dropna():
        for el in Composition(formula).get_el_amt_dict():
            global_counter[el] += 1

    for method in METHOD_ORDER:
        g = df[df["source"] == method]
        counter: Counter[str] = Counter()
        for formula in g["formula_2d"].dropna():
            for el in Composition(formula).get_el_amt_dict():
                counter[el] += 1
        total = len(g)
        for el in sorted(set(counter) | set(global_counter), key=lambda sym: Element(sym).Z):
            count = counter.get(el, 0)
            pct = 100.0 * count / total if total else 0.0
            global_pct = 100.0 * global_counter.get(el, 0) / total_all if total_all else 0.0
            rows.append(
                {
                    "method": method,
                    "element": el,
                    "count": count,
                    "percentage": pct,
                    "global_percentage": global_pct,
                    "enrichment": pct - global_pct,
                }
            )

    FIG_DIR.mkdir(parents=True, exist_ok=True)
    DATA_DIR.mkdir(parents=True, exist_ok=True)
    OUT_CSV.parent.mkdir(parents=True, exist_ok=True)
    out_df = pd.DataFrame(rows)
    out_df.to_csv(OUT_CSV, index=False)
    return out_df, df


def draw_periodic_panel(ax, enrichments: dict[str, float], cmap, norm, panel_label: str):
    positions = build_positions()
    ax.set_xlim(0.0, 19.0)
    ax.set_ylim(10.8, -0.5)
    ax.axis("off")
    ax.set_facecolor("#ffffff")

    absent_color = "#f4f6f8"
    text_absent = "#a2b0b9"
    box_size = 0.88

    all_symbols = [Element.from_Z(z).symbol for z in range(1, 119)]
    for symbol in all_symbols:
        if symbol not in positions:
            continue
        col, row = positions[symbol]
        x, y = col - 0.5, row - 0.5
        enrichment = enrichments.get(symbol)
        
        if enrichment is not None:
            face = cmap(norm(enrichment))
            tcolor = text_color(face)
            fw = "bold"
        else:
            face = absent_color
            tcolor = text_absent
            fw = "normal"
            
        rect = FancyBboxPatch(
            (x, y), box_size, box_size,
            boxstyle="round,pad=0.02",
            facecolor=face,
            edgecolor="#ffffff",
            linewidth=1.0,
        )
        ax.add_patch(rect)
        
        ax.text(
            x + box_size / 2, y + box_size / 2, symbol,
            ha="center", va="center",
            fontsize=10.5, fontweight=fw,
            color=tcolor,
        )

    for row, label, tag in [(6, "57–71", "La-Lu"), (7, "89–103", "Ac-Lr")]:
        x, y = 3 - 0.5, row - 0.5
        rect = FancyBboxPatch(
            (x, y), box_size, box_size,
            boxstyle="round,pad=0.02",
            facecolor="#ffffff",
            edgecolor="#cbd3da",
            linewidth=1.2,
        )
        rect.set_linestyle((0, (4, 4)))
        ax.add_patch(rect)
        ax.text(x + box_size / 2, y + box_size / 2 - 0.15, label, ha="center", va="center", fontsize=7.5, fontweight="bold", color="#6c7a86")
        ax.text(x + box_size / 2, y + box_size / 2 + 0.15, tag, ha="center", va="center", fontsize=6.5, fontstyle="italic", color="#9faab3")

    ax.text(0.5, -0.1, panel_label, fontsize=18, fontweight="bold", color="#1c2d3a")
    ax.text(2.6, 9 - 0.5 + box_size / 2, "Lanthanides", ha="right", va="center", fontsize=8.5, fontstyle="italic", color="#6c7a86")
    ax.text(2.6, 10 - 0.5 + box_size / 2, "Actinides", ha="right", va="center", fontsize=8.5, fontstyle="italic", color="#6c7a86")


def main() -> None:
    summary_df, df = prepare_data()

    cmap = mpl.colors.LinearSegmentedColormap.from_list(
        "enrichment_diverging",
        ["#2c7bb6", "#abd9e9", "#f7f7f7", "#fdae61", "#d7191c"],
        N=256,
    )
    max_abs = max(1.0, float(summary_df["enrichment"].abs().quantile(0.98)))
    norm = mpl.colors.TwoSlopeNorm(vmin=-max_abs, vcenter=0.0, vmax=max_abs)

    for idx, method in enumerate(METHOD_ORDER):
        method_df = summary_df[summary_df["method"] == method]
        enrichments = {row.element: row.enrichment for row in method_df.itertuples()}
        fig, ax = plt.subplots(figsize=(10.5, 6), constrained_layout=True)
        draw_periodic_panel(
            ax,
            enrichments,
            cmap,
            norm,
            f"({chr(97 + idx)})",
        )
        
        sm = mpl.cm.ScalarMappable(norm=norm, cmap=cmap)
        sm.set_array([])
        cbar = fig.colorbar(sm, ax=ax, fraction=0.025, pad=0.02, aspect=30, shrink=0.8)
        cbar.set_label("Enrichment relative to full 2D set (%)", rotation=90, labelpad=12, fontsize=11, fontweight="bold", color="#1c2d3a")
        cbar.ax.tick_params(labelsize=9, color="#364958", labelcolor="#364958")
        cbar.outline.set_edgecolor("#cbd3da")
        cbar.outline.set_linewidth(1.0)

        out_png, out_pdf = OUT_FILES[method]
        fig.savefig(out_png, dpi=600, bbox_inches="tight", pad_inches=0.1, facecolor="white")
        fig.savefig(out_pdf, bbox_inches="tight", pad_inches=0.1, facecolor="white")
        plt.close(fig)
        print(f"Saved {out_png}")
        print(f"Saved {out_pdf}")

    fig, axes = plt.subplots(3, 1, figsize=(11.2, 15.5), constrained_layout=True)
    for idx, (ax, method) in enumerate(zip(axes, METHOD_ORDER)):
        method_df = summary_df[summary_df["method"] == method]
        enrichments = {row.element: row.enrichment for row in method_df.itertuples()}
        draw_periodic_panel(
            ax,
            enrichments,
            cmap,
            norm,
            f"({chr(97 + idx)})",
        )

    sm = mpl.cm.ScalarMappable(norm=norm, cmap=cmap)
    sm.set_array([])
    cbar = fig.colorbar(sm, ax=axes, fraction=0.022, pad=0.012, aspect=38, shrink=0.95)
    cbar.set_label("Enrichment relative to full 2D set (%)", rotation=90, labelpad=12, fontsize=11, fontweight="bold", color="#1c2d3a")
    cbar.ax.tick_params(labelsize=9, color="#364958", labelcolor="#364958")
    cbar.outline.set_edgecolor("#cbd3da")
    cbar.outline.set_linewidth(1.0)

    fig.savefig(OUT_COMBINED_PNG, dpi=600, bbox_inches="tight", pad_inches=0.08, facecolor="white")
    fig.savefig(OUT_COMBINED_PDF, bbox_inches="tight", pad_inches=0.08, facecolor="white")
    plt.close(fig)
    print(f"Saved {OUT_COMBINED_PNG}")
    print(f"Saved {OUT_COMBINED_PDF}")

    print(f"Saved {OUT_CSV}")


if __name__ == "__main__":
    main()
