from __future__ import annotations

from pathlib import Path

import matplotlib as mpl
import matplotlib.pyplot as plt
import numpy as np
import pandas as pd


BASE_DIR = Path("/Volumes/J/research/2D_materials/3.23/paper_conclusions")
INPUT_CSV = BASE_DIR / "route_parent_composition_relation_stats.csv"
OUT_DATA = BASE_DIR / "figure_assets" / "data" / "route_parent_composition_relation_plot_data.csv"
OUT_PNG = BASE_DIR / "figure_assets" / "figures" / "figure_route_parent_composition_relation.png"
OUT_PDF = BASE_DIR / "figure_assets" / "figures" / "figure_route_parent_composition_relation.pdf"


def main() -> None:
    mpl.rcParams.update(
        {
            "font.family": "serif",
            "font.serif": ["Times New Roman", "Times", "DejaVu Serif"],
            "axes.linewidth": 0.8,
            "xtick.major.width": 0.8,
            "ytick.major.width": 0.8,
        }
    )

    order = ["Topological route", "Layered route", "Hybrid route"]
    relabel = {
        "same reduced formula": "Stoichiometry preserved",
        "same elements, different ratio": "Same elements, different ratio",
        "proper element subset of parent": "Element subset released",
    }
    colors = {
        "Stoichiometry preserved": "#76B7C9",
        "Same elements, different ratio": "#F6D78B",
        "Element subset released": "#E76F51",
    }

    df = pd.read_csv(INPUT_CSV)
    df = df[df["relation"].isin(relabel)].copy()
    df["relation"] = df["relation"].map(relabel)
    df["percentage"] = pd.to_numeric(df["percentage"], errors="coerce")
    df["count"] = pd.to_numeric(df["count"], errors="coerce")
    df["route"] = pd.Categorical(df["route"], categories=order, ordered=True)
    df = df.sort_values(["route"])
    OUT_DATA.parent.mkdir(parents=True, exist_ok=True)
    df.to_csv(OUT_DATA, index=False)

    fig, ax = plt.subplots(figsize=(9.0, 4.8), dpi=300)

    y = np.arange(len(order))
    left = np.zeros(len(order))

    for relation in relabel.values():
        vals = []
        counts = []
        for route in order:
            row = df[(df["route"] == route) & (df["relation"] == relation)].iloc[0]
            vals.append(float(row["percentage"]))
            counts.append(int(row["count"]))
        vals = np.array(vals)
        bars = ax.barh(
            y,
            vals,
            left=left,
            height=0.62,
            color=colors[relation],
            edgecolor="white",
            linewidth=1.2,
            label=relation,
        )
        for i, (bar, pct, count) in enumerate(zip(bars, vals, counts)):
            if pct < 5:
                continue
            x = left[i] + pct / 2
            txt_color = "white" if relation in {"Stoichiometry preserved", "Element subset released"} else "#303030"
            ax.text(
                x,
                bar.get_y() + bar.get_height() / 2,
                f"{pct:.1f}%",
                ha="center",
                va="center",
                fontsize=11,
                color=txt_color,
                fontweight="semibold",
            )
        left += vals

    # Add total counts on right
    totals = (
        df.groupby("route", observed=True)["count"]
        .sum()
        .reindex(order)
        .fillna(0)
        .astype(int)
        .to_numpy()
    )
    for yi, total in zip(y, totals):
        ax.text(101.2, yi, f"n = {total:,}", ha="left", va="center", fontsize=11, color="#444444")

    ax.set_xlim(0, 110)
    ax.set_yticks(y)
    ax.set_yticklabels(order, fontsize=12)
    ax.set_xlabel("Fraction of candidates within each route (%)", fontsize=12)
    ax.set_xticks(np.arange(0, 101, 20))
    ax.grid(axis="x", color="#D9D9D9", linewidth=0.8, alpha=0.8)
    ax.set_axisbelow(True)
    ax.invert_yaxis()

    for spine in ["top", "right"]:
        ax.spines[spine].set_visible(False)

    ax.legend(
        loc="upper center",
        bbox_to_anchor=(0.5, 1.20),
        ncol=3,
        frameon=False,
        fontsize=10.5,
        handlelength=1.6,
        columnspacing=1.2,
    )

    plt.subplots_adjust(left=0.21, right=0.90, top=0.78, bottom=0.18)
    fig.savefig(OUT_PNG, bbox_inches="tight")
    fig.savefig(OUT_PDF, bbox_inches="tight")
    plt.close(fig)


if __name__ == "__main__":
    main()
