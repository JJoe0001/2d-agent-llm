from __future__ import annotations

from pathlib import Path

import matplotlib.pyplot as plt
import numpy as np
import pandas as pd


BASE = Path("/Volumes/J/research/2D_materials/3.23/paper_conclusions/figure_assets")
DATA = BASE / "data" / "energy_analysis_dataset.csv"
FIG_DIR = BASE / "figures"

OUT1_PNG = FIG_DIR / "figure_energy_formation_by_method.png"
OUT1_PDF = FIG_DIR / "figure_energy_formation_by_method.pdf"
OUT2_PNG = FIG_DIR / "figure_energy_parent_ehull_by_method.png"
OUT2_PDF = FIG_DIR / "figure_energy_parent_ehull_by_method.pdf"
OUT3_PNG = FIG_DIR / "figure_energy_vs_area_by_method.png"
OUT3_PDF = FIG_DIR / "figure_energy_vs_area_by_method.pdf"

METHOD_ORDER = [
    "Computational exfoliation (Mounet et al.)",
    "Top-down approach (Zhou et al.)",
    "GALOCS + XCP/BONDDEL hybrid (this work)",
]

METHOD_COLORS = {
    "Computational exfoliation (Mounet et al.)": "#E64B35",
    "Top-down approach (Zhou et al.)": "#4DBBD5",
    "GALOCS + XCP/BONDDEL hybrid (this work)": "#00A087",
}

SHORT_LABELS = {
    "Computational exfoliation (Mounet et al.)": "Topological route",
    "Top-down approach (Zhou et al.)": "Layered route",
    "GALOCS + XCP/BONDDEL hybrid (this work)": "Hybrid route",
}

plt.rcParams.update(
    {
        "font.family": "serif",
        "font.serif": ["Times New Roman", "STIXGeneral", "DejaVu Serif"],
        "mathtext.fontset": "stix",
        "font.size": 12,
        "axes.labelsize": 13,
        "xtick.labelsize": 11,
        "ytick.labelsize": 11,
    }
)


def add_boxplot(ax: plt.Axes, values_by_method: list[np.ndarray], ylabel: str, ylim=None) -> None:
    positions = np.arange(1, len(METHOD_ORDER) + 1)
    parts = ax.violinplot(
        values_by_method,
        positions=positions,
        showmeans=False,
        showmedians=False,
        showextrema=False,
        widths=0.82,
    )
    for body, method in zip(parts["bodies"], METHOD_ORDER):
        body.set_facecolor(METHOD_COLORS[method])
        body.set_edgecolor("white")
        body.set_alpha(0.45)

    bp = ax.boxplot(
        values_by_method,
        positions=positions,
        patch_artist=True,
        widths=0.28,
        showfliers=False,
        medianprops={"color": "black", "linewidth": 1.2},
        whiskerprops={"color": "#444444", "linewidth": 1.0},
        capprops={"color": "#444444", "linewidth": 1.0},
        boxprops={"edgecolor": "#444444", "linewidth": 1.0},
    )
    for patch, method in zip(bp["boxes"], METHOD_ORDER):
        patch.set_facecolor(METHOD_COLORS[method])
        patch.set_alpha(0.85)

    ax.set_xticks(positions, [SHORT_LABELS[m] for m in METHOD_ORDER], rotation=10)
    ax.set_ylabel(ylabel)
    ax.grid(axis="y", color="#dddddd", linewidth=0.8)
    ax.set_axisbelow(True)
    for spine in ["top", "right"]:
        ax.spines[spine].set_visible(False)
    if ylim is not None:
        ax.set_ylim(*ylim)


def binned_median_curve(x: np.ndarray, y: np.ndarray, bins: np.ndarray) -> tuple[np.ndarray, np.ndarray]:
    centers: list[float] = []
    meds: list[float] = []
    for lo, hi in zip(bins[:-1], bins[1:]):
        mask = (x >= lo) & (x < hi)
        if mask.sum() < 20:
            continue
        centers.append(np.sqrt(lo * hi))
        meds.append(float(np.median(y[mask])))
    return np.array(centers), np.array(meds)


def main() -> None:
    FIG_DIR.mkdir(parents=True, exist_ok=True)
    df = pd.read_csv(DATA)

    formation_values = [
        df.loc[df["source"] == method, "formation_energy_eV"].to_numpy()
        for method in METHOD_ORDER
    ]
    ehull_values = [
        df.loc[df["source"] == method, "bulk_ehull_mp_eV_per_atom"].dropna().to_numpy()
        for method in METHOD_ORDER
    ]

    fig, ax = plt.subplots(figsize=(8.2, 5.2), constrained_layout=True)
    add_boxplot(ax, formation_values, "CHGNet formation energy (eV atom$^{-1}$)", ylim=(-8.2, 0.5))
    fig.savefig(OUT1_PNG, dpi=400, bbox_inches="tight")
    fig.savefig(OUT1_PDF, bbox_inches="tight")
    plt.close(fig)

    fig, ax = plt.subplots(figsize=(8.2, 5.2), constrained_layout=True)
    add_boxplot(ax, ehull_values, "Parent bulk $E_{\\mathrm{hull}}$ (eV atom$^{-1}$)", ylim=(-0.01, 0.42))
    fig.savefig(OUT2_PNG, dpi=400, bbox_inches="tight")
    fig.savefig(OUT2_PDF, bbox_inches="tight")
    plt.close(fig)

    fig, ax = plt.subplots(figsize=(8.6, 5.5), constrained_layout=True)
    for method in METHOD_ORDER:
        sub = df[df["source"] == method]
        x = sub["inplane_area_A2"].to_numpy()
        y = sub["formation_energy_eV"].to_numpy()
        ax.scatter(
            x,
            y,
            s=8,
            alpha=0.10,
            linewidths=0,
            color=METHOD_COLORS[method],
            label=SHORT_LABELS[method],
            rasterized=True,
        )
        bins = np.geomspace(max(5.0, x.min()), x.max() + 1e-9, 22)
        cx, cy = binned_median_curve(x, y, bins)
        ax.plot(cx, cy, color=METHOD_COLORS[method], linewidth=2.0)

    ax.set_xscale("log")
    ax.set_xlabel("In-plane area ($\\AA^2$)")
    ax.set_ylabel("CHGNet formation energy (eV atom$^{-1}$)")
    ax.set_ylim(-8.2, 0.5)
    ax.grid(color="#e2e2e2", linewidth=0.8)
    ax.set_axisbelow(True)
    for spine in ["top", "right"]:
        ax.spines[spine].set_visible(False)
    ax.legend(frameon=False, loc="lower right")
    fig.savefig(OUT3_PNG, dpi=400, bbox_inches="tight")
    fig.savefig(OUT3_PDF, bbox_inches="tight")
    plt.close(fig)

    print(f"Saved {OUT1_PNG}")
    print(f"Saved {OUT2_PNG}")
    print(f"Saved {OUT3_PNG}")


if __name__ == "__main__":
    main()
