from __future__ import annotations

from collections import Counter
from pathlib import Path

import matplotlib as mpl
import matplotlib.pyplot as plt
from matplotlib.patches import FancyBboxPatch
import pandas as pd
from pymatgen.core import Composition, Element


DATA_ROOT = Path("/Volumes/J/research/2D_materials/3.23/paper_conclusions")
BASE = DATA_ROOT / "figure_assets"
INPUT = DATA_ROOT / "exfoliation_energy_preparation_table.csv"
OUT_PNG = BASE / "figures" / "figure_element_prevalence_heatmap.png"
OUT_PDF = BASE / "figures" / "figure_element_prevalence_heatmap.pdf"
OUT_CSV = BASE / "data" / "element_prevalence_heatmap_data.csv"

plt.rcParams.update(
    {
        "font.family": "serif",
        "font.serif": ["Times New Roman", "STIXGeneral", "DejaVu Serif"],
        "mathtext.fontset": "stix",
        "font.size": 11,
        "axes.titlesize": 14,
        "axes.labelsize": 12,
        "xtick.labelsize": 10,
        "ytick.labelsize": 10,
        "legend.fontsize": 10,
        "figure.dpi": 150,
        "savefig.dpi": 600,
        "savefig.bbox": "tight",
        "savefig.pad_inches": 0.05,
    }
)

LAN = [
    "La", "Ce", "Pr", "Nd", "Pm", "Sm", "Eu", "Gd", "Tb", "Dy", "Ho", "Er", "Tm", "Yb", "Lu"
]
ACT = [
    "Ac", "Th", "Pa", "U", "Np", "Pu", "Am", "Cm", "Bk", "Cf", "Es", "Fm", "Md", "No", "Lr"
]

def build_positions() -> dict[str, tuple[int, int]]:
    positions: dict[str, tuple[int, int]] = {}
    for z in range(1, 119):
        el = Element.from_Z(z)
        symbol = el.symbol
        if symbol in LAN:
            positions[symbol] = (LAN.index(symbol) + 3, 9)
        elif symbol in ACT:
            positions[symbol] = (ACT.index(symbol) + 3, 10)
        else:
            positions[symbol] = (el.group, el.row)
    return positions


def text_color(rgba) -> str:
    if isinstance(rgba, str):
        return "black"
    r, g, b, _ = rgba
    luminance = 0.299 * r + 0.587 * g + 0.114 * b
    return "white" if luminance < 0.65 else "#1a252c"


def main() -> None:
    df = pd.read_csv(INPUT, usecols=["formula_2d"])
    total = len(df)
    counts: Counter[str] = Counter()
    for formula in df["formula_2d"].dropna():
        for el in Composition(formula).get_el_amt_dict():
            counts[el] += 1

    rows = []
    for el, count in sorted(counts.items(), key=lambda kv: Element(kv[0]).Z):
        rows.append({
            "element": el,
            "count": count,
            "fraction": count / total,
            "percentage": 100.0 * count / total,
        })
    OUT_CSV.parent.mkdir(parents=True, exist_ok=True)
    pd.DataFrame(rows).to_csv(OUT_CSV, index=False)

    positions = build_positions()

    cmap = mpl.colors.LinearSegmentedColormap.from_list(
        "science_blue",
        ["#edf5fc", "#c0daf0", "#76b4e0", "#2c84c7", "#0d4c82"],
        N=256,
    )
    vmax = 20.0
    norm = mpl.colors.Normalize(vmin=0, vmax=vmax)

    fig, ax = plt.subplots(figsize=(14.5, 7.2))
    ax.set_xlim(0.5, 19.6)
    ax.set_ylim(11.2, 0.5)
    ax.axis("off")
    ax.set_facecolor("#ffffff")

    edge_color = "#ffffff"
    edge_width = 1.0
    absent_color = "#f4f6f8"
    text_absent = "#a2b0b9"

    all_symbols = [Element.from_Z(z).symbol for z in range(1, 119)]
    for symbol in all_symbols:
        if symbol not in positions:
            continue
        col, row = positions[symbol]
        x, y = col - 0.5, row - 0.5
        pct = 100.0 * counts.get(symbol, 0) / total
        if pct > 0:
            face = cmap(norm(pct))
            tcolor = text_color(face)
            fw = "bold"
        else:
            face = absent_color
            tcolor = text_absent
            fw = "normal"
            
        rect = FancyBboxPatch(
            (x, y), 0.9, 0.9,
            boxstyle="round,pad=0.02",
            facecolor=face,
            edgecolor=edge_color,
            linewidth=edge_width,
        )
        ax.add_patch(rect)

        ax.text(
            x + 0.45, y + 0.45, symbol,
            ha="center", va="center",
            fontsize=11, fontweight=fw,
            color=tcolor,
        )

    placeholder_face = "#ffffff"
    placeholder_edge = "#cbd3da"
    placeholder_specs = [
        {"row": 6, "label": "57–71", "tag": "La-Lu"},
        {"row": 7, "label": "89–103", "tag": "Ac-Lr"},
    ]
    for spec in placeholder_specs:
        x, y = 3 - 0.5, spec["row"] - 0.5
        rect = FancyBboxPatch(
            (x, y), 0.9, 0.9,
            boxstyle="round,pad=0.02",
            facecolor=placeholder_face,
            edgecolor=placeholder_edge,
            linewidth=1.2,
            linestyle="--",
        )
        ax.add_patch(rect)
        ax.text(x + 0.45, y + 0.35, spec["label"], ha="center", va="center", fontsize=8.5, fontweight="bold", color="#6c7a86")
        ax.text(x + 0.45, y + 0.65, spec["tag"], ha="center", va="center", fontsize=7.2, fontstyle="italic", color="#8a8f94")

    ax.text(3, 8.7, "Lanthanides", fontsize=9, fontstyle="italic", color="#6c757d", ha="left")
    ax.text(3, 9.7, "Actinides", fontsize=9, fontstyle="italic", color="#6c757d", ha="left")

    ax.text(0.6, 0.75, "(b)", fontsize=18, fontweight="bold", color="#2c3e50")

    sm = mpl.cm.ScalarMappable(norm=norm, cmap=cmap)
    sm.set_array([])
    cbar = fig.colorbar(sm, ax=ax, fraction=0.025, pad=0.02, aspect=40, shrink=0.8, location='right')
    cbar.set_label("Occurrence in unique 2D candidates (%)", rotation=90, labelpad=12, fontsize=11, fontweight="semibold")
    cbar.ax.tick_params(labelsize=9, width=0.8)
    from matplotlib.ticker import FormatStrFormatter
    cbar.ax.yaxis.set_major_formatter(FormatStrFormatter("%.1f"))

    fig.savefig(OUT_PNG, dpi=600, bbox_inches="tight", pad_inches=0.05)
    fig.savefig(OUT_PDF, bbox_inches="tight", pad_inches=0.05)
    print(f"Saved {OUT_PNG}")
    print(f"Saved {OUT_PDF}")
    print(f"Saved {OUT_CSV}")

    plt.close(fig)

if __name__ == "__main__":
    main()
