from __future__ import annotations

from pathlib import Path

import matplotlib.pyplot as plt
import numpy as np
import pandas as pd


BASE = Path("/Volumes/J/research/2D_materials/3.23/paper_conclusions/figure_assets")
DATA = BASE / "data" / "energy_analysis_dataset.csv"
FIG_DIR = BASE / "figures"

OUT_PNG = FIG_DIR / "figure_energy_formation_distribution.png"
OUT_PDF = FIG_DIR / "figure_energy_formation_distribution.pdf"

METHOD_ORDER = [
    "Computational exfoliation (Mounet et al.)",
    "Top-down approach (Zhou et al.)",
    "GALOCS + XCP/BONDDEL hybrid (this work)",
]

METHOD_COLORS = {
    "Computational exfoliation (Mounet et al.)": "#E64B35",
    "Top-down approach (Zhou et al.)": "#4DBBD5",
    "GALOCS + XCP/BONDDEL hybrid (this work)": "#00A087",
}

SHORT_LABELS = {
    "Computational exfoliation (Mounet et al.)": "Topological route",
    "Top-down approach (Zhou et al.)": "Layered route",
    "GALOCS + XCP/BONDDEL hybrid (this work)": "Hybrid route",
}

plt.rcParams.update(
    {
        "font.family": "serif",
        "font.serif": ["Times New Roman", "STIXGeneral", "DejaVu Serif"],
        "mathtext.fontset": "stix",
        "font.size": 12,
        "axes.labelsize": 13,
        "xtick.labelsize": 11,
        "ytick.labelsize": 11,
        "legend.fontsize": 11,
    }
)


def main() -> None:
    FIG_DIR.mkdir(parents=True, exist_ok=True)
    df = pd.read_csv(DATA)

    # Focus on the physically relevant main window and suppress extreme outliers.
    x_min, x_max = -8.2, 0.2
    bins = np.linspace(x_min, x_max, 85)

    fig, ax = plt.subplots(figsize=(8.6, 5.4), constrained_layout=True)

    ymax = 0.0
    for method in METHOD_ORDER:
        vals = df.loc[df["source"] == method, "formation_energy_eV"].to_numpy()
        vals = vals[np.isfinite(vals)]
        vals = vals[(vals >= x_min) & (vals <= x_max)]
        hist, edges = np.histogram(vals, bins=bins, density=True)
        centers = 0.5 * (edges[:-1] + edges[1:])
        # Smooth the binned density with a Gaussian kernel to avoid the
        # jagged histogram look while keeping the distribution faithful.
        sigma_bins = 1.6
        radius = int(np.ceil(4 * sigma_bins))
        grid = np.arange(-radius, radius + 1, dtype=float)
        kernel = np.exp(-0.5 * (grid / sigma_bins) ** 2)
        kernel /= kernel.sum()
        smooth = np.convolve(hist, kernel, mode="same")
        ymax = max(ymax, smooth.max())

        ax.fill_between(
            centers,
            smooth,
            alpha=0.22,
            color=METHOD_COLORS[method],
        )
        ax.plot(
            centers,
            smooth,
            color=METHOD_COLORS[method],
            linewidth=2.1,
            label=SHORT_LABELS[method],
        )

        median = float(np.median(vals))
        ax.axvline(median, color=METHOD_COLORS[method], linestyle="--", linewidth=1.3, alpha=0.95)
        ax.text(
            median,
            ymax * 1.03 if ymax > 0 else 0.1,
            f"{median:.2f}",
            rotation=90,
            ha="center",
            va="bottom",
            color=METHOD_COLORS[method],
            fontsize=10,
        )

    ax.set_xlabel("CHGNet formation energy (eV atom$^{-1}$)")
    ax.set_ylabel("Density")
    ax.set_xlim(x_min, x_max)
    ax.set_ylim(0, ymax * 1.22)
    ax.grid(axis="y", color="#dddddd", linewidth=0.8)
    ax.set_axisbelow(True)
    for spine in ["top", "right"]:
        ax.spines[spine].set_visible(False)
    ax.spines["left"].set_color("#444444")
    ax.spines["bottom"].set_color("#444444")
    ax.legend(frameon=False, loc="upper left")

    fig.savefig(OUT_PNG, dpi=400, bbox_inches="tight")
    fig.savefig(OUT_PDF, bbox_inches="tight")
    print(f"Saved {OUT_PNG}")


if __name__ == "__main__":
    main()
