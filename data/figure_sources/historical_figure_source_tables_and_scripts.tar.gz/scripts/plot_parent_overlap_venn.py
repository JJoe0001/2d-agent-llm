import math
from pathlib import Path

import matplotlib.pyplot as plt
from matplotlib.patches import Circle


BASE = Path("/Volumes/J/research/2D_materials/3.23/paper_conclusions/figure_assets")
OUT_PNG = BASE / "figures" / "figure_parent_overlap_methods.png"
OUT_PDF = BASE / "figures" / "figure_parent_overlap_methods.pdf"
OUT_REPORT = Path("/Volumes/J/research/2D_materials/3.23/paper_conclusions/report_venn_diagram.png")

plt.rcParams.update(
    {
        "font.family": "serif",
        "font.serif": ["Times New Roman", "Times", "DejaVu Serif"],
        "font.size": 16,
    }
)

subsets = {
    "100": 20884,
    "010": 13025,
    "001": 3904,
    "110": 7662,
    "101": 780,
    "011": 1075,
    "111": 287,
}

a_total = subsets["100"] + subsets["110"] + subsets["101"] + subsets["111"]
b_total = subsets["010"] + subsets["110"] + subsets["011"] + subsets["111"]
c_total = subsets["001"] + subsets["101"] + subsets["011"] + subsets["111"]

scale = 0.0060
r_a = math.sqrt(a_total) * scale
r_b = math.sqrt(b_total) * scale
r_c = math.sqrt(c_total) * scale

center_a = (-0.95, 0.08)
center_b = (0.85, 0.08)
# Keep the layered-route circle close enough to the other two circles so that
# the small three-route overlap is visible rather than implied only by a label.
center_c = (0.08, -0.62)

# 与全局方法论严格绑定
colors = {
    "a": "#E64B35",
    "b": "#00A087",
    "c": "#4DBBD5",
}

fig, ax = plt.subplots(figsize=(12.5, 8.6))
for center, radius, color in [
    (center_a, r_a, colors["a"]),
    (center_b, r_b, colors["b"]),
    (center_c, r_c, colors["c"]),
]:
    ax.add_patch(Circle(center, radius, facecolor=color, edgecolor="#222222", linewidth=1.6, alpha=0.58))

# method labels
ax.text(center_a[0] - r_a * 0.88, center_a[1] + r_a * 1.08,
        "Topological route", ha="center", va="center", fontsize=17)
ax.text(center_b[0] + r_b * 0.88, center_b[1] + r_b * 1.08,
        "Hybrid route", ha="center", va="center", fontsize=17)
ax.text(center_c[0], center_c[1] - r_c * 1.28,
        "Layered route", ha="center", va="center", fontsize=17)

# subset counts
positions = {
    "100": (center_a[0] - r_a * 0.53, center_a[1] + 0.02),
    "010": (center_b[0] + r_b * 0.40, center_b[1] + 0.02),
    "001": (center_c[0], center_c[1] - r_c * 0.42),
    "110": (-0.02, 0.36),
    "101": (-0.25, -0.35),
    "011": (0.36, -0.34),
    "111": (0.03, -0.25),
}
for key, value in subsets.items():
    x, y = positions[key]
    bbox = None
    weight = "normal"
    if key == "111":
        bbox = dict(boxstyle="round,pad=0.16", facecolor="white", edgecolor="none", alpha=0.82)
        weight = "bold"
    ax.text(x, y, f"{value:,}", ha="center", va="center", fontsize=16, fontweight=weight, bbox=bbox)

ax.set_aspect("equal")
ax.set_xlim(-2.35, 2.35)
ax.set_ylim(-1.65, 1.75)
ax.axis("off")

fig.tight_layout()
fig.savefig(OUT_PNG, dpi=300, bbox_inches="tight")
fig.savefig(OUT_PDF, bbox_inches="tight")
fig.savefig(OUT_REPORT, dpi=300, bbox_inches="tight")

print(OUT_PNG)
print(OUT_PDF)
print(OUT_REPORT)
